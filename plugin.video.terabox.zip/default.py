
import xbmcplugin
import xbmcgui
import xbmcaddon
import sys

# Constants
ADDON_HANDLE = int(sys.argv[1])
ADDON = xbmcaddon.Addon()
BASE_URL = "https://terabox.com/s/1_rjluFiaNGFIpJw9T7LNRw"

def main():
    # Add the Terabox link as an item
    list_item = xbmcgui.ListItem(label="Watch Movie from Terabox")
    list_item.setInfo("video", {"title": "Terabox Movie", "genre": "Unknown"})
    list_item.setPath(BASE_URL)
    list_item.setProperty("IsPlayable", "true")
    
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=BASE_URL, listitem=list_item, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

if __name__ == "__main__":
    main()
